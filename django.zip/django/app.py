from flask import Flask, render_template
import csv
import pandas as pd
import numpy as np
import json
from collections import defaultdict
import tensorflow as tf
from keras.models import load_model
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler

sc=joblib.load("scaler.save")
model = load_model("model.h5")
def make_pred(pred):
#PREDICTION
    prediction = []

    input_symptoms = pred
    for i in range(len(df1)):
        flag=1
        for j in range(len(input_symptoms)):
            symp = input_symptoms[j]
            if symp not in df1["Symptom"][i]:
                flag = 0
                break
        if flag==1:
            prediction.append(df1["Disease"][i])
    print("SYMPTOMES RECIEVED : ",end='')
    print(pred)
    print(prediction)


df = pd.read_excel('raw_data.xlsx')

data = df.fillna(method='ffill')
#data.head()


# Process Disease and Symptom Names
def process_data(data):
    data_list = []
    data_name = data.replace('^', '_').split('_')
    n = 1
    for names in data_name:
        if (n % 2 == 0):
            data_list.append(names)
        n += 1
    return data_list


disease_list = []
disease_symptom_dict = defaultdict(list)
disease_symptom_count = {}
count = 0

for idx, row in data.iterrows():

    # Get the Disease Names
    if (row['Disease'] != "\xc2\xa0") and (row['Disease'] != ""):
        disease = row['Disease']
        disease_list = process_data(data=disease)
        count = row['Count of Disease Occurrence']

    # Get the Symptoms Corresponding to Diseases
    if (row['Symptom'] != "\xc2\xa0") and (row['Symptom'] != ""):
        symptom = row['Symptom']
        symptom_list = process_data(data=symptom)
        for d in disease_list:
            for s in symptom_list:
                disease_symptom_dict[d].append(s)
            disease_symptom_count[d] = count

# See that the data is Processed Correctly
#disease_symptom_dict

# Count of Disease Occurence w.r.t each Disease
#disease_symptom_count

df1 = pd.DataFrame(list(disease_symptom_dict.items()), columns=['Disease', 'Symptom'])
#df1.head()

#for vals in disease_symptom_count.items():
#    print(vals[1])

df1["Number_of_Occurences"] = 0

for i in range(len(df1)):
    df1["Number_of_Occurences"][i] = disease_symptom_count[df1["Disease"][i]]

###################################################################################################

##################################################################################################
app = Flask(__name__)

@app.route('/')
def index():
    return 'WELCOME TO SERVERANOS'

@app.route('/home')
def hello():
    return render_template('./home.html')

@app.route('/api', methods=['POST'])
def api():
    json_data = request.get_json(force=True)
    data_j = json_data.values()
    data_j = list(data_j)
    l = len(data_j)
    make_pred(data_j)
    return Response(json.dumps({'yo':'yo'}),  mimetype='application/json')

 @app.route('/gettime', methods = ['POST'])
 def gettime():
 	l=[]
 	json_data=request.get_json(force=true)
 	data_j=json_data.values()
 	l.append(data_j)
 	test_data = pd.DataFrame(l, columns = ['Disease', 'hrs', 'mins', 'secs', 'num_docs', 'num_pen_req'])
 	test_data = sc.transform(test_data)
 	x=model.predict(test_data)
 	return Response(json.dumps({"yo":x}), mimetype='application/json')





from flask import Flask, abort, jsonify, request, render_template, Response

if __name__ == '__main__':
    app.run(debug = True, threaded = True, host = '0.0.0.0' ,port = 8082)

########################################################################################################################



#return Response(json.dumps({"price":predictions}),  mimetype='application/json')
