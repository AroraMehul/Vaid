from flask import Flask, abort, jsonify, request, render_template,Response
import numpy as np
import pandas as pd
import tensorflow as tf
from keras.models import load_model
import json
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler

sc=joblib.load("scaler.save")
oe=joblib.load("onehot.save")
le=joblib.load("label.save")
model = load_model("model.h5")


model = load_model("model.h5")
app = Flask(__name__)

@app.route('/')
def home():
    return "surprise mother fucker"

@app.route('/api', methods = ['POST'])

def api():
    json_data = request.get_json(force=True)

    data = json_data.values()
    data=list(data)
    l=[]
    #l=np.array().tolist()
    #json_data=request.get_json(force=true)
    #data_j=json_data.values()
    l.append(data)

    test_data = pd.DataFrame([data], columns = ['Disease', 'hrs', 'mins', 'secs', 'num_docs', 'num_pen_req'])
    test_data['Disease']=le.transform(test_data['Disease'])
    test_data=oe.transform(test_data).toarray()
    test_data = sc.transform(test_data)
    x=model.predict(test_data)
    #response={}
    #response=predictions
    return Response(json.dumps({"price":x.tolist()}),  mimetype='application/json')

if __name__=='__main__':
    app.run(port=8080,debug=True)

